Pre-requisite
Ruby on rails 5 stack is installed and working perfectly fine on your system.

Rails version 5.2.3
Ruby version 2.5.1

Mysql database installed and local mysql server running

Steps to setup the application:
1. check out the code for the repository.
2. Open terminal and navigate to the parent folder in which you checked out the code, and then execute following cmds
    (a) bundle install
    (b) rake db:migrate
    (c) start the server - rails server
3. A rails server is running at localhost port 3000 => http://localhost:3000/